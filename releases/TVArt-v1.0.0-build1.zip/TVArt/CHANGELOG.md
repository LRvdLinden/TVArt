# Changelog

## 1.0.0 (build 1) — 2026-10-18

- Initial native Apple TV release project.
- Artist-first browsing with 18 artist and period selections.
- Live public-domain artworks from Chicago and Metropolitan Museum collections.
- Full-screen timed art display with zoom, shuffle, remote control, clock, favorites and settings.
