# TVArt for Apple TV

Native SwiftUI tvOS art-gallery app. **Bundle ID:** `nl.lrvdlinden.tvart` · **Version:** `1.0.0` · **Build:** `1`.

## Features

- Select artist or Renaissance collection → choose painting → fullscreen art player.
- Artists: Van Gogh, Rembrandt, Monet, Mondrian, Gauguin, Manet, Munch, Goya, Vermeer, Cézanne, Renoir, Degas, Turner, Hokusai, Botticelli, Dalí, Klimt, plus Renaissance.
- Automatically advance at 20 / 30 seconds or 1 / 2 / 5 / 8 minutes; shuffle or sequential.
- Gentle zoom, fade, optional floating clock, Siri Remote left/right and play/pause controls.
- Favorites stored locally, paintings metadata, remote image caching, network error/empty states.
- Content fetched at runtime using public APIs; no paid API keys or account.

## Open in Xcode

1. Open `TVArt.xcodeproj` in Xcode 16 or later on a Mac.
2. Select the **TVArt** scheme and an Apple TV simulator or connected Apple TV.
3. Signing & Capabilities: choose your Apple Developer team; the bundle identifier is `nl.lrvdlinden.tvart`.
4. Build and run (⌘R). Target: tvOS 17.0+.

Internet access is required to fetch artwork. Museums can occasionally be unavailable or have no public-domain images for a given artist, in which case the gallery shows an error/empty state. The app never promises 75 works for each artist.

## Rights & APIs

- Art Institute of Chicago public API: https://api.artic.edu/docs/
- Metropolitan Museum public API: https://metmuseum.github.io/
- Images are limited to works the source flags public domain. Verify rights and museum usage policies for commercial distribution. Attribution is included in the artwork details.
- Independently implemented; not affiliated with the referenced commercial art apps.

## Validation

The provided project has not been compiled with Apple's Xcode toolchain in this Linux environment; verify and archive on macOS/Xcode before submitting to TestFlight.
