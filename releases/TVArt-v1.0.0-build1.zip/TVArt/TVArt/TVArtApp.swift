import SwiftUI

@main
struct TVArtApp: App {
    @StateObject private var settings = GallerySettings()
    var body: some Scene {
        WindowGroup {
            ArtistHomeView()
                .environmentObject(settings)
                .preferredColorScheme(.dark)
        }
    }
}

struct Artist: Identifiable, Hashable {
    let id: String
    let name: String
    let years: String
    let terms: [String]
    let symbol: String
    let category: Bool
    static let collection: [Artist] = [
        .init(id:"vangogh", name:"Vincent van Gogh", years:"1853–1890", terms:["Vincent van Gogh"], symbol:"sun.max", category:false),
        .init(id:"rembrandt", name:"Rembrandt van Rijn", years:"1606–1669", terms:["Rembrandt van Rijn","Rembrandt"], symbol:"person.crop.rectangle", category:false),
        .init(id:"monet", name:"Claude Monet", years:"1840–1926", terms:["Claude Monet"], symbol:"water.waves", category:false),
        .init(id:"mondrian", name:"Piet Mondrian", years:"1872–1944", terms:["Piet Mondrian","Piet Mondriaan"], symbol:"square.grid.3x3", category:false),
        .init(id:"renaissance", name:"Renaissance", years:"1400–1600", terms:["Leonardo da Vinci","Raphael","Sandro Botticelli","Titian"], symbol:"building.columns", category:true),
        .init(id:"gauguin", name:"Paul Gauguin", years:"1848–1903", terms:["Paul Gauguin"], symbol:"leaf", category:false),
        .init(id:"manet", name:"Édouard Manet", years:"1832–1883", terms:["Édouard Manet","Edouard Manet"], symbol:"paintbrush.pointed", category:false),
        .init(id:"munch", name:"Edvard Munch", years:"1863–1944", terms:["Edvard Munch"], symbol:"moon.stars", category:false),
        .init(id:"goya", name:"Francisco Goya", years:"1746–1828", terms:["Francisco Goya","Francisco de Goya"], symbol:"eye", category:false),
        .init(id:"vermeer", name:"Johannes Vermeer", years:"1632–1675", terms:["Johannes Vermeer"], symbol:"lightbulb", category:false),
        .init(id:"cezanne", name:"Paul Cézanne", years:"1839–1906", terms:["Paul Cézanne","Paul Cezanne"], symbol:"mountain.2", category:false),
        .init(id:"renoir", name:"Pierre-Auguste Renoir", years:"1841–1919", terms:["Pierre-Auguste Renoir","Auguste Renoir"], symbol:"figure.dance", category:false),
        .init(id:"degas", name:"Edgar Degas", years:"1834–1917", terms:["Edgar Degas"], symbol:"figure.skating", category:false),
        .init(id:"turner", name:"J. M. W. Turner", years:"1775–1851", terms:["Joseph Mallord William Turner","J. M. W. Turner"], symbol:"cloud.sun", category:false),
        .init(id:"hokusai", name:"Katsushika Hokusai", years:"1760–1849", terms:["Katsushika Hokusai","Hokusai"], symbol:"water.waves", category:false),
        .init(id:"botticelli", name:"Sandro Botticelli", years:"1445–1510", terms:["Sandro Botticelli"], symbol:"sparkles", category:false),
        .init(id:"dali", name:"Salvador Dalí", years:"1904–1989", terms:["Salvador Dali","Salvador Dalí"], symbol:"clock", category:false),
        .init(id:"klimt", name:"Gustav Klimt", years:"1862–1918", terms:["Gustav Klimt"], symbol:"circle.hexagongrid", category:false)
    ]
}

struct Artwork: Identifiable, Hashable {
    let id: String
    let title: String
    let artist: String
    let date: String
    let imageURL: URL
    let source: String
    let detailURL: URL?
    var thumbnailURL: URL { imageURL }
}

@MainActor final class GallerySettings: ObservableObject {
    @AppStorage("duration") var duration: Int = 30
    @AppStorage("clock") var clock: Bool = false
    @AppStorage("random") var random: Bool = true
    @AppStorage("zoom") var zoom: Bool = true
    @AppStorage("hints") var hints: Bool = true
    @AppStorage("favorites") private var favoriteData: String = ""
    var favorites: Set<String> { Set(favoriteData.split(separator:"|").map(String.init)) }
    func toggle(_ id: String) {
        var current = favorites
        if current.contains(id) { current.remove(id) } else { current.insert(id) }
        favoriteData = current.sorted().joined(separator:"|")
        objectWillChange.send()
    }
}

private struct AICResponse: Decodable {
    struct Entry: Decodable {
        let id: Int
        let title: String
        let artist_title: String?
        let date_display: String?
        let image_id: String?
        let is_public_domain: Bool?
    }
    struct Config: Decodable { let iiif_url: String? }
    let data: [Entry]
    let config: Config?
}
private struct MetSearch: Decodable { let objectIDs: [Int]? }
private struct MetObject: Decodable {
    let objectID: Int
    let title: String
    let artistDisplayName: String?
    let objectDate: String?
    let primaryImage: String?
    let primaryImageSmall: String?
    let isPublicDomain: Bool?
    let objectURL: String?
}

actor MuseumService {
    static let shared = MuseumService()
    private let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 18
        c.requestCachePolicy = .returnCacheDataElseLoad
        c.urlCache = URLCache(memoryCapacity: 40_000_000, diskCapacity: 300_000_000)
        return URLSession(configuration:c)
    }()
    private var cache: [String:[Artwork]] = [:]
    func load(_ artist: Artist) async throws -> [Artwork] {
        if let saved = cache[artist.id], !saved.isEmpty { return saved }
        var combined: [Artwork] = []
        for term in artist.terms {
            if Task.isCancelled { throw CancellationError() }
            async let chicago = chicagoArt(term: term)
            async let met = metropolitanArt(term: term)
            let (a, m) = await (chicago, met)
            combined += a + m
        }
        let unique = Dictionary(grouping: combined, by: { $0.id }).compactMap { $0.value.first }
        let sorted = unique.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
        if !sorted.isEmpty { cache[artist.id] = sorted }
        return sorted
    }
    private func chicagoArt(term: String) async -> [Artwork] {
        var components = URLComponents(string:"https://api.artic.edu/api/v1/artworks/search")!
        components.queryItems = [
            URLQueryItem(name:"q", value:term),
            URLQueryItem(name:"query[term][is_public_domain]", value:"true"),
            URLQueryItem(name:"limit", value:"100"),
            URLQueryItem(name:"fields", value:"id,title,artist_title,date_display,image_id,is_public_domain")
        ]
        guard let url = components.url,
              let (data, response) = try? await session.data(from:url),
              (response as? HTTPURLResponse)?.statusCode == 200,
              let payload = try? JSONDecoder().decode(AICResponse.self, from:data) else { return [] }
        let base = payload.config?.iiif_url ?? "https://www.artic.edu/iiif/2"
        return payload.data.compactMap { item in
            guard item.is_public_domain == true, let key = item.image_id,
                  let by = item.artist_title,
                  matches(by, search:term),
                  let image = URL(string:"\(base)/\(key)/full/1686,/0/default.jpg") else { return nil }
            return Artwork(id:"aic-\(item.id)", title:item.title, artist:by,
                           date:item.date_display ?? "", imageURL:image,
                           source:"Art Institute of Chicago", detailURL:URL(string:"https://www.artic.edu/artworks/\(item.id)"))
        }
    }
    private func metropolitanArt(term: String) async -> [Artwork] {
        var components = URLComponents(string:"https://collectionapi.metmuseum.org/public/collection/v1/search")!
        components.queryItems = [URLQueryItem(name:"hasImages",value:"true"),
                                 URLQueryItem(name:"artistOrCulture",value:"true"),
                                 URLQueryItem(name:"q",value:term)]
        guard let url = components.url,
              let (data, response) = try? await session.data(from:url),
              (response as? HTTPURLResponse)?.statusCode == 200,
              let ids = try? JSONDecoder().decode(MetSearch.self,from:data).objectIDs else { return [] }
        // Limit remote requests to protect the public API and the TV's memory.
        var output: [Artwork] = []
        for id in ids.prefix(24) {
            if Task.isCancelled { break }
            guard let url = URL(string:"https://collectionapi.metmuseum.org/public/collection/v1/objects/\(id)"),
                  let (data,response) = try? await session.data(from:url),
                  (response as? HTTPURLResponse)?.statusCode == 200,
                  let item = try? JSONDecoder().decode(MetObject.self,from:data),
                  item.isPublicDomain == true,
                  let artist = item.artistDisplayName, matches(artist,search:term),
                  let imageString = item.primaryImage, !imageString.isEmpty,
                  let image = URL(string:imageString) else { continue }
            output.append(Artwork(id:"met-\(item.objectID)",title:item.title,artist:artist,
                                  date:item.objectDate ?? "",imageURL:image,
                                  source:"The Metropolitan Museum of Art",detailURL:URL(string:item.objectURL ?? "")))
        }
        return output
    }
    private func matches(_ artist: String, search: String) -> Bool {
        let a = artist.folding(options:[.diacriticInsensitive,.caseInsensitive],locale:.current)
        let b = search.folding(options:[.diacriticInsensitive,.caseInsensitive],locale:.current)
        return a.contains(b) || b.contains(a) || (b == "rembrandt" && a.contains("rembrandt"))
    }
}

struct ArtistHomeView: View {
    @EnvironmentObject var settings: GallerySettings
    @State private var showingSettings = false
    private let columns = [GridItem(.adaptive(minimum:310),spacing:30)]
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:32) {
                    HStack(alignment:.firstTextBaseline) {
                        VStack(alignment:.leading,spacing:8) {
                            Text("TVArt").font(.system(size:78,weight:.semibold,design:.serif)).foregroundStyle(.white)
                            Text("Jouw museum. Op het grootste scherm.")
                                .font(.title3).foregroundStyle(.gray)
                        }
                        Spacer()
                        Button { showingSettings = true } label: { Label("Instellingen",systemImage:"gearshape") }
                    }
                    Text("Kies een kunstenaar of collectie").font(.title2).bold()
                    LazyVGrid(columns:columns,spacing:32) {
                        ForEach(Artist.collection) { artist in
                            NavigationLink(value:artist) {
                                VStack(alignment:.leading,spacing:17) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius:18).fill(LinearGradient(colors:[Color(red:0.27,green:0.22,blue:0.18),Color(red:0.07,green:0.09,blue:0.13)],startPoint:.topLeading,endPoint:.bottomTrailing))
                                        Image(systemName:artist.symbol).font(.system(size:88,weight:.ultraLight)).foregroundStyle(.white.opacity(0.8))
                                    }.frame(height:205)
                                    Text(artist.name).font(.title3.weight(.semibold)).lineLimit(1)
                                    Text(artist.years).font(.callout).foregroundStyle(.gray)
                                }.padding(15).background(.white.opacity(0.055),in:RoundedRectangle(cornerRadius:25))
                            }.buttonStyle(.card)
                        }
                    }
                    Text("Kunstwerken worden geladen uit openbare museumcollecties. Internetverbinding vereist.")
                        .font(.footnote).foregroundStyle(.gray)
                }.padding(65)
            }
            .navigationDestination(for:Artist.self) { artist in ArtGalleryView(artist:artist) }
            .sheet(isPresented:$showingSettings) { SettingsView() }
        }.tint(.white)
    }
}

struct ArtGalleryView: View {
    let artist: Artist
    @State private var artworks: [Artwork] = []
    @State private var loading = true
    @State private var failed = false
    @State private var showFavorites = false
    @EnvironmentObject var settings: GallerySettings
    private let cols = [GridItem(.adaptive(minimum:340),spacing:35)]
    var filtered: [Artwork] { showFavorites ? artworks.filter { settings.favorites.contains($0.id) } : artworks }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:30) {
                Text(artist.name).font(.system(size:56,design:.serif)).bold()
                HStack(spacing:24) {
                    Text("\(artworks.count) schilderijen").foregroundStyle(.gray)
                    Toggle("Alleen favorieten",isOn:$showFavorites).fixedSize()
                    if !artworks.isEmpty {
                        NavigationLink { SlideshowView(artworks:filtered.isEmpty ? artworks : filtered,startIndex:0) } label: {
                            Label("Start diavoorstelling",systemImage:"play.fill")
                        }.buttonStyle(.borderedProminent)
                    }
                }.font(.headline)
                if loading { ProgressView("Schilderijen ophalen bij musea…").font(.title3).frame(maxWidth:.infinity,minHeight:300) }
                else if filtered.isEmpty {
                    VStack(spacing:20) {
                        Text(failed ? "De museumcollecties zijn momenteel niet bereikbaar." : showFavorites ? "Nog geen favorieten voor deze kunstenaar." : "Geen rechtenvrije werken met afbeelding gevonden.")
                        Button("Opnieuw proberen") { Task { await refresh() } }
                    }.font(.title3).frame(maxWidth:.infinity,minHeight:320)
                } else {
                    LazyVGrid(columns:cols,spacing:30) {
                        ForEach(Array(filtered.enumerated()),id:\.element.id) { index, artwork in
                            NavigationLink {
                                SlideshowView(artworks:filtered,startIndex:index)
                            } label: {
                                VStack(alignment:.leading,spacing:12) {
                                    RemoteArtImage(url:artwork.thumbnailURL)
                                        .frame(height:220).clipped().background(Color.white.opacity(0.04))
                                        .clipShape(RoundedRectangle(cornerRadius:13))
                                    Text(artwork.title).font(.headline).lineLimit(2)
                                    Text(artwork.date).font(.caption).foregroundStyle(.gray).lineLimit(1)
                                }.padding(12)
                            }.buttonStyle(.card)
                        }
                    }
                }
            }.padding(65)
        }
        .task(id:artist.id) { await refresh() }
    }
    private func refresh() async {
        loading = true; failed = false
        let data = try? await MuseumService.shared.load(artist)
        if !Task.isCancelled {
            artworks = data ?? []
            failed = data == nil || artworks.isEmpty
            loading = false
        }
    }
}

struct RemoteArtImage: View {
    let url: URL
    var body: some View {
        AsyncImage(url:url,transaction:Transaction(animation:.easeInOut(duration:0.7))) { phase in
            switch phase {
            case .success(let image): image.resizable().scaledToFit().frame(maxWidth:.infinity,maxHeight:.infinity)
            case .failure: Image(systemName:"photo.artframe").resizable().scaledToFit().padding(50).foregroundStyle(.gray)
            case .empty: ProgressView()
            @unknown default: EmptyView()
            }
        }.accessibilityLabel("Kunstwerk")
    }
}

struct SlideshowView: View {
    let artworks: [Artwork]
    let startIndex: Int
    @EnvironmentObject var settings: GallerySettings
    @Environment(\.dismiss) private var dismiss
    @State private var index: Int = 0
    @State private var paused = false
    @State private var showOverlay = true
    @State private var showInfo = false
    @State private var zoomIn = false
    @State private var now = Date()
    @State private var settingsOpen = false
    private var active: Artwork { artworks[index] }
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                RemoteArtImage(url:active.imageURL)
                    .id(active.id)
                    .scaleEffect(settings.zoom && zoomIn ? 1.055 : 1)
                    .animation(settings.zoom ? .linear(duration:Double(settings.duration)) : .none,value:zoomIn)
                    .transition(.opacity)
                    .frame(width:geo.size.width,height:geo.size.height)
                if showOverlay {
                    VStack {
                        HStack {
                            VStack(alignment:.leading,spacing:7) {
                                Text(active.title).font(.title2).bold()
                                Text("\(active.artist) · \(active.date)").font(.headline)
                            }.shadow(radius:10)
                            Spacer()
                            Text("\(index+1) / \(artworks.count)").font(.headline)
                        }.padding(45).background(.linearGradient(colors:[.black.opacity(0.78),.clear],startPoint:.top,endPoint:.bottom))
                        Spacer()
                        HStack(spacing:24) {
                            Button { previous() } label: { Image(systemName:"backward.fill") }
                            Button { paused.toggle() } label: { Image(systemName:paused ? "play.fill" : "pause.fill") }
                            Button { next() } label: { Image(systemName:"forward.fill") }
                            Button { settings.toggle(active.id) } label: { Image(systemName:settings.favorites.contains(active.id) ? "heart.fill" : "heart") }
                            Button { showInfo.toggle() } label: { Image(systemName:"info.circle") }
                            Button { settingsOpen = true } label: { Image(systemName:"gearshape") }
                        }.font(.title2).buttonStyle(.bordered).padding(30)
                    }
                }
                if settings.clock {
                    VStack { Spacer(); Text(now,style:.time).font(.system(size:30,weight:.medium,design:.rounded)).shadow(color:.black,radius:8).offset(x:sin(now.timeIntervalSince1970 / 95)*55).padding(.bottom,showOverlay ? 120 : 25) }
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { showOverlay.toggle() }
            .onPlayPauseCommand { paused.toggle(); showOverlay = true }
            .onMoveCommand { direction in
                switch direction {
                case .left: previous()
                case .right: next()
                case .up,.down: showOverlay.toggle()
                @unknown default: break
                }
            }
            .sheet(isPresented:$settingsOpen) { SettingsView() }
            .alert(active.title,isPresented:$showInfo) {
                Button("Sluiten",role:.cancel) { }
            } message: { Text("\(active.artist) · \(active.date)\nBron: \(active.source)") }
            .task(id:active.id) {
                zoomIn = false
                if settings.zoom { zoomIn = true }
            }
            .task {
                index = min(max(0,startIndex),max(0,artworks.count-1))
                UIApplication.shared.isIdleTimerDisabled = true
                defer { UIApplication.shared.isIdleTimerDisabled = false }
                while !Task.isCancelled {
                    try? await Task.sleep(for:.seconds(1))
                    now = Date()
                }
            }
            .task(id:"\(index)-\(paused)-\(settings.duration)-\(settingsOpen)") {
                guard !paused && !settingsOpen else { return }
                try? await Task.sleep(for:.seconds(settings.duration))
                guard !Task.isCancelled else { return }
                next()
            }
        }.ignoresSafeArea()
    }
    private func next() {
        guard artworks.count > 1 else { return }
        withAnimation(.easeInOut(duration:0.85)) {
            if settings.random && artworks.count > 2 {
                let others = artworks.indices.filter { $0 != index }
                index = others.randomElement() ?? (index+1)%artworks.count
            } else { index = (index+1)%artworks.count }
        }
    }
    private func previous() { withAnimation(.easeInOut(duration:0.85)) { index = (index - 1 + artworks.count)%artworks.count } }
}

struct SettingsView: View {
    @EnvironmentObject var settings: GallerySettings
    @Environment(\.dismiss) private var dismiss
    private let durations:[Int] = [20,30,60,120,300,480]
    var body: some View {
        NavigationStack {
            Form {
                Section("Diavoorstelling") {
                    Picker("Tijd per schilderij",selection:$settings.duration) {
                        ForEach(durations,id:\.self) { s in Text(s < 60 ? "\(s) seconden" : "\(s/60) minuten").tag(s) }
                    }
                    Toggle("Willekeurige volgorde",isOn:$settings.random)
                    Toggle("Subtiele zoom (Ken Burns)",isOn:$settings.zoom)
                    Toggle("Klok tijdens weergave",isOn:$settings.clock)
                    Toggle("Bedieningstips tonen",isOn:$settings.hints)
                }
                Section("TVArt") {
                    Text("Versie 1.0.0 (1)")
                    Text("Werken worden rechtstreeks uit de openbare collecties van het Art Institute of Chicago en The Metropolitan Museum of Art geladen. Alleen werken die door de bron als publiek domein zijn gemarkeerd worden weergegeven.")
                        .font(.footnote)
                }
            }
            .navigationTitle("Instellingen")
            .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Gereed") { dismiss() } } }
        }
    }
}
